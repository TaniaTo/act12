package doce;


import java.util.Map.Entry;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class AddressBook {
	public static void main(String[ ]args) {
	
		
		Scanner tem=new Scanner(System.in);
		Map<Integer,String> Contactos = new HashMap<>();
		
	
	int re;
	boolean salir= false;
	int telefono;
	String nombre;
	
	
	while(!salir) {
		//MENU
		System.out.println("******AGENDA TELEFONICA *****");
		System.out.println("1.A�adir contacto");
		System.out.println("2.Listar Contactos");
		System.out.println("3.Comprobar si hay un contacto");
		System.out.println("4.Eliminar contacto");
		System.out.println("5.Salir");
		try {
			System.out.println("Elija una opcion");
			re=tem.nextInt();
			
			switch (re) {
		
	
case 1:
	//A�ADIR CONTACTO 
	System.out.println("");
	System.out.println("Digita tu numero de telefono");
	telefono=tem.nextInt();
	
	System.out.println("Digita el nombre del contacto");
	nombre =tem.next();
	
	if(!Contactos.containsKey(telefono)) {
		Contactos.put(telefono,nombre);
	System.out.println("El registro se a�adio con exitoso");
	}else {
		System.out.println("Ya existe el contacto");
		
	}
	
	break;
	
case 2:
	//Listar contactos�
	if(Contactos.entrySet().isEmpty()) {
		System.out.println("");
		System.out.println("No existe contactos con ese registro");
		
	}else {
		for(Map.Entry<Integer, String> i:Contactos.entrySet()) {
			System.out.println("");
			System.out.println("El telefono es  es ->"+ i.getKey() +" Nombre del contacto es  ->" + i.getValue());
		}
	}
	
	break;
	
case 3:
	//Comprobar Si hay contacto
	System.out.println("");
	System.out.println("Digita el telefono que deseas saber si hay ");
	telefono=tem.nextInt();
	
	if(Contactos.containsKey(telefono)) {
		System.out.println("Si existe el contacto");
	}else {
		System.out.println("NO existe contcato");
		
	}
	break;
	
case 4:
	//Eliminar 
	
	System.out.println("");
	System.out.println("Desea el telefono que desea eliminar");
	telefono=tem.nextInt();
	
	if(Contactos.containsKey(telefono)) {
		Contactos.remove(telefono);
		System.out.println("Se a eliminado ");
	}else {
		System.out.println("No existe el telefono");
	}
	
	break ;
	
case 5: 
	System.exit(0);
	System.out.println("");
	System.out.println("Gracias por su registro");
	break;
	
	
	default:
		System.out.println("No es correcta esta opcion");
		break;
}
          }catch(Exception e) {
System.out.println("Error: "+e);
          }
	}
}
}



